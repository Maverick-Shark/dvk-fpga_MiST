srec_cat 000.bin -binary --byte-swap 2 -o 000.mif -Memory_Initialization_File 16 -obs=2
srec_cat 055.bin -binary --byte-swap 2 -o 055.mif -Memory_Initialization_File 16 -obs=2
srec_cat 279.bin -binary --byte-swap 2 -o 279.mif -Memory_Initialization_File 16 -obs=2
srec_cat 134e.bin -binary --byte-swap 2 -o 134e.mif -Memory_Initialization_File 16 -obs=2
srec_cat 134.bin -binary --byte-swap 2 -o 134.mif -Memory_Initialization_File 16 -obs=2
srec_cat 013-basic.bin -binary --byte-swap 2 -o 013-basic.mif -Memory_Initialization_File 16 -obs=2
srec_cat 058-focal.bin -binary --byte-swap 2 -o 058-focal.mif -Memory_Initialization_File 16 -obs=2

